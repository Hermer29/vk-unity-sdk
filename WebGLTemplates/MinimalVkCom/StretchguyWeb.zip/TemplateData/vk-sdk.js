﻿const sdkRootObjectName = "VKSDK";

function notifyFriendsLevelReached(level)
{
}

function showBannerAdvertising()
{
    vkBridge.send('VKWebAppShowBannerAd', {
        banner_location: 'bottom'
    })
        .then((data) => {
            if (data.result) {
                // Баннерная реклама отобразилась
                console.log("Banner ad shown");
                return;
            }
            console.log("Banner ad NOT shown");
        })
        .catch((error) => {
            // Ошибка
            console.log(error);
        });
}

vkBridge.send('VKWebAppInit').then(data => {});

showBannerAdvertising();

function showInterstitial() {
    const advertisingShow = vkBridge.send('VKWebAppShowNativeAds',{ad_format:"interstitial"});
    advertisingShow.then(x => {
        window.unityInstance.SendMessage("VKSDK", 'OnInterstitialEnded', name);
        console.log("Interstitial advertising ended");
    });
    advertisingShow.catch(x => {
        window.unityInstance.SendMessage("VKSDK", 'OnInterstitialEnded', name);
    });
}

function showRewarded(name) {
    const advertisingShow = vkBridge.send('VKWebAppShowNativeAds', {ad_format: "reward"});
    advertisingShow.then(data => {
        console.log(data);
        window.unityInstance.SendMessage("VKSDK", 'OnRewardedEnded', name);
    });
    advertisingShow.catch(ex => {
        console.log("Rewarded ad showing failed: " + ex.toString());
        window.unityInstance.SendMessage("VKSDK", 'OnRewardedFailed', name)
    });
}

function authenticate() {
    var authenticationRequest = vkBridge.send('VKWebAppGetUserInfo');
    authenticationRequest.then(info => window.unityInstance.SendMessage("VKSDK", 'OnAuthenticated'));
}

function share() {
    var shareRequest = vkBridge.send('VKWebAppShare', {
        link: ""
    });
    shareRequest.then((data) => {
        if (data.result) {
            console.log("Sharing succeeded");
        }
    });
    shareRequest.catch((error) => console.error(error));
}
